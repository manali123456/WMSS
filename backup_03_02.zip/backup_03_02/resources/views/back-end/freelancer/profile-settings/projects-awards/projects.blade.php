<freelancer_project
    :ph_project_title="'{{ trans('lang.ph_project_title') }}'"
    :ph_project_url="'{{ trans('lang.ph_project_url') }}'">
</freelancer_project>